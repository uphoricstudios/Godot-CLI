# Godot-CLI
An in-editor CLI tool to help with small automations without having to leave the editor.
